package com.capgemini.MobilePurchase.dao;

public interface IQueryMapper {
	static String INSERT_QUERY = "INSERT INTO purchasedetails(purchaseid,cname,mailid,phoneno,purchasedate,mobileid) VALUES(purchaseid_sequence.nextval,?,?,?,sysdate,?)";
	static String GET_PURCHASE_ID = "SELECT purchaseid_sequence.CURRVAL FROM DUAL";
	static String RETRIVE_ALL_QUERY = "SELECT * FROM MOBILES";
	static String GET_MOBILE_ID = "SELECT MOBILEID FROM MOBILES";
	static String UPDATE_STOCK_QUANTITY = "update mobiles set quantity = (quantity-1) where mobileid = ?";
	static String SEARCH_MOBILE = "select purchaseid, cname, name from purchasedetails pd inner join mobiles m on pd.mobileid = m.mobileid where purchaseid = ?";
	static String NEW_STOCK = "INSERT INTO MOBILES(MOBILEID,NAME,PRICE,QUANTITY) VALUES(mobileid_seq.nextval,?,?,?)";
	static String AUTH_USER = "SELECT * FROM SELLER"; 
}
