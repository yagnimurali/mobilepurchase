package com.capgemini.MobilePurchase.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.MobilePurchase.beans.Mobiles;
import com.capgemini.MobilePurchase.beans.Purchasedetails;
import com.capgemini.MobilePurchase.beans.Seller;
import com.capgemini.MobilePurchase.exceptions.MobilePurchaseException;
import com.capgemini.MobilePurchase.util.DBConnecton;

public class MobilePurchaseDaoImp implements IMobilePurchaseDao {

	Logger logger = Logger.getRootLogger();

	public MobilePurchaseDaoImp() {
		PropertyConfigurator.configure("resources//log4j.properties");

	}

	@Override
	public Purchasedetails purchaseMobile(Purchasedetails pd) throws MobilePurchaseException {

		Connection conn;

		PreparedStatement insertStmt = null;

		try {

			conn = DBConnecton.getConnection();

			insertStmt = conn.prepareStatement(IQueryMapper.INSERT_QUERY);
			insertStmt.setString(1, pd.getCustomerName());
			insertStmt.setString(2, pd.getMailId());
			insertStmt.setString(3, pd.getPhoneNumber());
			insertStmt.setInt(4, pd.getMobileId());

			System.out.println(pd.getCustomerName());
			System.out.println(pd.getMailId());
			System.out.println(pd.getPhoneNumber());
			System.out.println(pd.getPurchasedate());
			System.out.println(pd.getMobileId());

			int result = insertStmt.executeUpdate();

			if (result != 1) {
				logger.debug("values not inserted");
				throw new MobilePurchaseException("Sorry! insert not performed");
			} else {
				conn.commit();
			}

		} catch (SQLException | NullPointerException e) {

			throw new MobilePurchaseException(e.getMessage());
		}

		return pd;
	}

	public int getPurchaseseqId() throws MobilePurchaseException {

		Connection conn;
		PreparedStatement getPurchseStmt = null;
		ResultSet purchaseIdResult = null;
		int purchaseid = 0;
		try {
			conn = DBConnecton.getConnection();
			getPurchseStmt = conn.prepareStatement(IQueryMapper.GET_PURCHASE_ID);
			purchaseIdResult = getPurchseStmt.executeQuery();
			if (purchaseIdResult.next()) {
				purchaseid = purchaseIdResult.getInt(1);
				logger.info("Registation done: " + purchaseid);
			}
		} catch (MobilePurchaseException e) {
			throw new MobilePurchaseException("Sorry purchseid not genrated");
		} catch (SQLException e) {
			e.printStackTrace();
			throw new MobilePurchaseException("Sorry purchseid sql exception genrated");

		}

		return purchaseid;

	}

	public List<Mobiles> retriveAllDetails() throws MobilePurchaseException {

		Connection con = DBConnecton.getConnection();
		int mobilesCount = 0;

		PreparedStatement psMobStmt = null;
		ResultSet resultset = null;

		List<Mobiles> mobilesList = new ArrayList<Mobiles>();
		try {
			psMobStmt = con.prepareStatement(IQueryMapper.RETRIVE_ALL_QUERY);
			resultset = psMobStmt.executeQuery();

			while (resultset.next()) {
				Mobiles mbbean = new Mobiles();
				mbbean.setMobileid(resultset.getInt(1));
				mbbean.setName(resultset.getString(2));
				mbbean.setPrice(resultset.getDouble(3));
				mbbean.setQuantity(resultset.getInt(4));
				mobilesList.add(mbbean);

				mobilesCount++;
			}

		} catch (SQLException sqlException) {
			logger.error(sqlException.getMessage());
			throw new MobilePurchaseException("Tehnical problem occured. Refer log");
		}

		finally {
			try {
				resultset.close();
				psMobStmt.close();
				// con.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				throw new MobilePurchaseException("Error in closing db connection");

			}
		}

		if (mobilesCount == 0)
			return null;
		else
			return mobilesList;
	}

	@Override
	public List<Integer> getMobileIds() throws MobilePurchaseException {

		Connection con = DBConnecton.getConnection();
		int mobileIDsCount = 0;

		PreparedStatement psMobIDStmt = null;
		ResultSet resultsetMobId = null;

		List<Integer> mobileIDsList = new ArrayList<Integer>();
		try {
			psMobIDStmt = con.prepareStatement(IQueryMapper.GET_MOBILE_ID);
			resultsetMobId = psMobIDStmt.executeQuery();

			while (resultsetMobId.next()) {
				mobileIDsList.add(resultsetMobId.getInt(1));

				mobileIDsCount++;
			}

		} catch (SQLException sqlException) {
			logger.error(sqlException.getMessage());
			throw new MobilePurchaseException("Tehnical problem occured. Refer log");
		}

		finally {
			try {
				resultsetMobId.close();
				psMobIDStmt.close();
				// con.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				throw new MobilePurchaseException("Error in closing db connection");

			}
		}

		if (mobileIDsCount == 0)
			return null;
		else
			return mobileIDsList;

	}

	@Override
	public void updateMobileQuantity(Purchasedetails pd) throws MobilePurchaseException {
		Connection con = DBConnecton.getConnection();
		PreparedStatement psUpdateQty = null;
		try {
			psUpdateQty = con.prepareStatement(IQueryMapper.UPDATE_STOCK_QUANTITY);
			psUpdateQty.setInt(1, pd.getMobileId());
			int result = psUpdateQty.executeUpdate();

			if (result != 1) {
				logger.debug("values not inserted");
				throw new MobilePurchaseException("update filed");
			} else {
				con.commit();
			}

		} catch (SQLException | MobilePurchaseException e) {
			throw new MobilePurchaseException("Quantity update not done");
		}

	}

	@Override
	public List<Object> seearchMobile(int purchaseid) throws MobilePurchaseException {

		Connection con = DBConnecton.getConnection();
		int mobilesCount = 0;

		PreparedStatement psMobSerStmt = null;
		ResultSet resultset = null;

		List<Object> searchList = new ArrayList<Object>();
		try {
			psMobSerStmt = con.prepareStatement(IQueryMapper.SEARCH_MOBILE);
			psMobSerStmt.setInt(1, purchaseid);
			resultset = psMobSerStmt.executeQuery();

			while (resultset.next()) {
				Purchasedetails pd2 = new Purchasedetails();
				Mobiles mbbean = new Mobiles();
				pd2.setPurchaseId(resultset.getInt(1));
				pd2.setCustomerName(resultset.getString(2));
				mbbean.setName(resultset.getString(3));
				searchList.add(pd2);
				searchList.add(mbbean);

				mobilesCount++;
			}

		} catch (SQLException sqlException) {
			logger.error(sqlException.getMessage());
			throw new MobilePurchaseException("Tehnical problem occured. Refer log");
		}

		if (mobilesCount == 0) {
			return null;
		} else {
			return searchList;
		}
	}

	@Override
	public Mobiles addNewStock(Mobiles ms) throws MobilePurchaseException {

		Connection conn;

		PreparedStatement insertStmt = null;

		try {

			conn = DBConnecton.getConnection();

			insertStmt = conn.prepareStatement(IQueryMapper.NEW_STOCK);
			insertStmt.setString(1, ms.getName());
			insertStmt.setDouble(2, ms.getPrice());
			insertStmt.setInt(3, ms.getQuantity());

			int result = insertStmt.executeUpdate();

			if (result != 1) {
				logger.debug("values not inserted");
				throw new MobilePurchaseException("Sorry! new stock insert not performed");
			} else {
				conn.commit();
			}

		} catch (SQLException | NullPointerException e) {

			throw new MobilePurchaseException(e.getMessage());
		}

		return ms;

	}

	@Override
	public List<Seller> authenticateUser() throws MobilePurchaseException {
		Connection conn;
		conn = DBConnecton.getConnection();
		int sellerCount = 0;
		PreparedStatement authUserStmt = null;
		List<Seller> sellerList = new ArrayList<Seller>();
		try {
			authUserStmt = conn.prepareStatement(IQueryMapper.AUTH_USER);
			ResultSet userResultSet = authUserStmt.executeQuery();
			while (userResultSet.next()) {
				Seller sebean = new Seller();
				sebean.setUserName(userResultSet.getString(1));
				sebean.setPassword(userResultSet.getString(2));
				
				sellerList.add(sebean);

				sellerCount++;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new MobilePurchaseException("auth cannot perform");
		}
		if(sellerCount == 0) {
			return null;
		}
		else {
		return sellerList;
		}
	}

}
