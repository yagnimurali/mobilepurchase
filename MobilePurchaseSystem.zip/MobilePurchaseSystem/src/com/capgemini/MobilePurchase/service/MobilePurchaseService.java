package com.capgemini.MobilePurchase.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Pattern;

import com.capgemini.MobilePurchase.beans.Mobiles;
import com.capgemini.MobilePurchase.beans.Purchasedetails;
import com.capgemini.MobilePurchase.beans.Seller;
import com.capgemini.MobilePurchase.dao.IMobilePurchaseDao;
import com.capgemini.MobilePurchase.dao.MobilePurchaseDaoImp;
import com.capgemini.MobilePurchase.exceptions.MobilePurchaseException;

public class MobilePurchaseService implements IMobilePurchaseService {

	IMobilePurchaseDao daoimp2;

	public Purchasedetails purchaseMobile(Purchasedetails pd) throws MobilePurchaseException {

		daoimp2 = new MobilePurchaseDaoImp();
		Purchasedetails pdseq;
		pdseq = daoimp2.purchaseMobile(pd);
		return pdseq;

	}

	@Override
	public boolean validateCustomerName(String cname) {
		String patterns = "[A-Z][a-z ]{1,20}";
		if (Pattern.matches(patterns, cname)) {
			return true;
		} else {
			return false;
		}

	}

	@Override
	public boolean validatePhoneNumber(String PhoneNumber) {
		String patterns1 = "\\d{10}";
		if (Pattern.matches(patterns1, PhoneNumber)) {
			return true;
		} else {

			return false;
		}

	}

	@Override
	public boolean validateMobileId(String MobileId) {
		String patterns1 = "\\d{4}";
		if (Pattern.matches(patterns1, MobileId)) {
			return true;
		} else {

			return false;
		}
	}

	@Override
	public boolean validateMailId(String MailId) {
		String patterns = "[A-Za-z0-9]{1,}[@][A-Za-z0-9.]{1,}";
		if (Pattern.matches(patterns, MailId)) {
			return true;
		} else {
			return false;
		}

	}

	@Override
	public List<Mobiles> retriveAllDetails() throws MobilePurchaseException {
		daoimp2 = new MobilePurchaseDaoImp();
		List<Mobiles> mobilesList = null;
		mobilesList = daoimp2.retriveAllDetails();
		return mobilesList;
	}

	@Override
	public int getPurchaseseqId() throws MobilePurchaseException {
		daoimp2 = new MobilePurchaseDaoImp();
		int purchaseid = daoimp2.getPurchaseseqId();
		return purchaseid;
	}

	@Override
	public List<Integer> getMobileIds() throws MobilePurchaseException {
		daoimp2 = new MobilePurchaseDaoImp();
		List<Integer> mobileIdsList = null;
		mobileIdsList = daoimp2.getMobileIds();
		return mobileIdsList;
	}

	@Override
	public void updateMobileQuantity(Purchasedetails pd) throws MobilePurchaseException {
		daoimp2 = new MobilePurchaseDaoImp();
		daoimp2.updateMobileQuantity(pd);

	}

	@Override
	public List<Object> seearchMobile(int purchaseid) throws MobilePurchaseException {
		daoimp2 = new MobilePurchaseDaoImp();
		List<Object> searchList = null;
		searchList = daoimp2.seearchMobile(purchaseid);
		return searchList;

	}

	@Override
	public Mobiles addNewStock(Mobiles ms) throws MobilePurchaseException {
		daoimp2 = new MobilePurchaseDaoImp();
		Mobiles ms1 = daoimp2.addNewStock(ms);
		return ms1;
	}

	@Override
	public boolean authenticateUser(String username, String password) throws MobilePurchaseException {
		daoimp2 = new MobilePurchaseDaoImp();
		List<Seller> sellerList = new ArrayList<Seller>();
		sellerList = daoimp2.authenticateUser();
		
		if (sellerList != null) {
			Iterator<Seller> i = sellerList.iterator();
			while (i.hasNext()) {
				Seller obj = i.next();
				if(obj.getUserName().equals(username)&&obj.getPassword().equals(password)) {
					return true;
				}
			}
			return false;
		}
		return false; 

	}
		
}
