package com.capgemini.doctors.dao;

public interface IQueryMapper {
	static String INSERT_QUERY = "";
	static String SEARCH_DOCTOR = "";
	static String GET_APPOINTMENT_DETAILS = "";
	static String GET_PROBLEM_NAMES ="SELECT PROBLEM FROM PROBLEMLIST";
}
